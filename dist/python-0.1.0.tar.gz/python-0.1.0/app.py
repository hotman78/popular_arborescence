import streamlit as st
import graphviz
from solve import solve

input = st.text_area("Input")

if input == "":
    st.text("Please enter input")
    st.stop()

graphlist = solve(input)
graph = graphviz.Digraph()

# st.graphviz_chart(graph.source)


# st.graphviz_chart()
