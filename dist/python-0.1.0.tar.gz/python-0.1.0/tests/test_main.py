class TestCreateXxx:
    # 通常の評価
    def test__can_print_aaa(self) -> None:
        assert 1

    # エラーがでることを評価
    def test__can_raise_error(self) -> None:
        assert 1
